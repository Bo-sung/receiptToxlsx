﻿#if NOESIS
using Noesis;
using NoesisApp;
#else
using System.Windows;
#endif

namespace Buttons
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
